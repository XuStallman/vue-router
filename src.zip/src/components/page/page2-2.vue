<template>
  <div id="page2-2">
    我是第二个三级菜单
  </div>
</template>

<script>
export default {
  name: 'page2-2'
}
</script>

<style>
#page2-2 {

}
</style>
