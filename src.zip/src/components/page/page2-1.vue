<template>
  <div id="page2-1">
    我是第一个三级菜单
  </div>
</template>

<script>
export default {
  name: 'page2-1'
}
</script>

<style>
#page2-1 {

}
</style>
