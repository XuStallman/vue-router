<template>
  <div id="page1-1">
    我是二级菜单
  </div>
</template>

<script>
export default {
  name: 'page1-1'
}
</script>

<style>
#page1-1 {
	font-size:50px;
	text-align: center;
}
</style>
